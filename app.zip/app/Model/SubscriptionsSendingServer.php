<?php

namespace Acelle\Model;

use Illuminate\Database\Eloquent\Model;

class SubscriptionsSendingServer extends Model
{
    //
}
