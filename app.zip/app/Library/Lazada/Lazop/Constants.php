<?php
namespace Acelle\Library\Lazada\Lazop;

class Constants
{
    public static $log_level_debug = "DEBUG";
    public static $log_level_info = "INFO";
    public static $log_level_error = "ERROR";
}
