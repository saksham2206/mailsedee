jQuery-ace
==========

Original repo: https://github.com/cheef/jquery-ace

jQuery plugin for ACE Code Editor, http://ace.ajax.org. It embeds ACE Code Editor to any choosen ``div`` or ``textarea``.

## How to install

See all documentation and examples here http://cheef.github.com/jquery-ace

## How to contribute

1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Add some feature'`)
4. Push to the branch (`git push origin my-new-feature`)
5. Create new Pull Request

## Author

Ivan Garmatenko **cheef.che at gmail.com**